import torch
from torch.utils.data import DataLoader

from datasets.kepler import KeplerDataset, kepler

from function_encoder.model.mlp import MLP
from function_encoder.model.neural_ode import NeuralODE, ODEFunc, rk4_step
from function_encoder.function_encoder import BasisFunctions, FunctionEncoder
from function_encoder.utils.training import train_step

import tqdm

if torch.cuda.is_available():
    device = "cuda"
elif torch.backends.mps.is_available():
    device = "mps"
else:
    device = "cpu"

torch.manual_seed(42)

# Load dataset

dataset = KeplerDataset(
    integrator=rk4_step,
    n_points=1000,
    n_example_points=100,
    dt_range=(0.1, 0.1),
    device=torch.device(device),
)
dataloader = DataLoader(dataset, batch_size=50)
dataloader_iter = iter(dataloader)

# Create model


def basis_function_factory():
    return NeuralODE(
        ode_func=ODEFunc(model=MLP(layer_sizes=[5, 64, 64, 4])),
        integrator=rk4_step,
    )


num_basis = 5
# Start with one basis function for progressive training
basis_functions = BasisFunctions(basis_function_factory())

model = FunctionEncoder(basis_functions).to(device)

# Train model

losses = []  # For plotting
scores = []  # For plotting
dataloader_coeffs = DataLoader(dataset, batch_size=100)
dataloader_coeffs_iter = iter(dataloader_coeffs)


def compute_explained_variance(model):
    _, _, _, _, example_y0, example_dt, example_y1 = next(dataloader_coeffs_iter)
    # Data is already on the correct device from the dataset

    coefficients, G = model.compute_coefficients((example_y0, example_dt), example_y1)

    # Compute explained variance from Gram matrix eigenvalues
    K = G.mean(dim=0)
    gram_eigenvalues, _ = torch.linalg.eigh(K)
    gram_eigenvalues = gram_eigenvalues.flip(0)  # Flip to descending order

    explained_variance_ratio = gram_eigenvalues / torch.sum(gram_eigenvalues)

    return explained_variance_ratio, gram_eigenvalues


def loss_function(model, batch):
    _, y0, dt, y1, y0_example, dt_example, y1_example = batch
    # Data is already on the correct device from the dataset

    coefficients, _ = model.compute_coefficients((y0_example, dt_example), y1_example)
    pred = model((y0, dt), coefficients=coefficients)

    pred_loss = torch.nn.functional.mse_loss(pred, y1)

    return pred_loss


# Train the first basis function
num_epochs = 100
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
with tqdm.tqdm(range(num_epochs), desc=f"basis 1/{num_basis}") as tqdm_bar:
    for epoch in tqdm_bar:
        batch = next(dataloader_iter)
        loss = train_step(model, optimizer, batch, loss_function)
        losses.append(loss)
        tqdm_bar.set_postfix({"loss": f"{loss:.2e}"})

model.eval()
with torch.no_grad():
    explained_variance_ratio, _ = compute_explained_variance(model)
    scores.append(explained_variance_ratio)

# Train the remaining basis functions progressively
for k in range(num_basis - 1):

    # Freeze all existing parameters except the new basis function
    for param in model.parameters():
        param.requires_grad = False

    # Create a new basis function and add it to the model
    new_basis_function = basis_function_factory()
    for param in new_basis_function.parameters():
        param.requires_grad = True

    new_basis_function = new_basis_function.to(device)
    model.basis_functions.basis_functions.append(new_basis_function)

    # Select only the trainable parameters
    trainable_params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.Adam(trainable_params, lr=1e-3)

    with tqdm.tqdm(range(num_epochs), desc=f"basis {k + 2}/{num_basis}") as tqdm_bar:
        for epoch in tqdm_bar:
            batch = next(dataloader_iter)
            loss = train_step(model, optimizer, batch, loss_function)
            losses.append(loss)
            tqdm_bar.set_postfix({"loss": f"{loss:.2e}"})

    model.eval()
    with torch.no_grad():
        explained_variance_ratio, _ = compute_explained_variance(model)
        scores.append(explained_variance_ratio)

# Plot results

import matplotlib.pyplot as plt

model.eval()
with torch.no_grad():
    # Generate a batch for visualization
    dataloader_eval = DataLoader(dataset, batch_size=9)
    batch = next(iter(dataloader_eval))

    M_central, y0, dt, y1, y0_example, dt_example, y1_example = batch
    # Data is already on the correct device from the dataset

    # Compute coefficients
    coefficients, G = model.compute_coefficients((y0_example, dt_example), y1_example)

    # Create plots
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))

    # Plot 1: Explained variance ratio
    ax1 = axes[0, 0]
    cumulative_scores = [torch.cumsum(score, dim=0) for score in scores]
    for i, score in enumerate(cumulative_scores):
        ax1.plot(score.cpu().numpy(), label=f"Basis {i+1}", marker="o")
    ax1.set_xlabel("Component")
    ax1.set_ylabel("Cumulative Explained Variance Ratio")
    ax1.set_title("PCA-like Analysis: Explained Variance")
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # Plot 2: Training loss
    ax2 = axes[0, 1]
    ax2.semilogy(losses)
    ax2.set_xlabel("Training Step")
    ax2.set_ylabel("Loss")
    ax2.set_title("Training Progress")
    ax2.grid(True, alpha=0.3)

    # Plot 3: Sample trajectories
    ax3 = axes[1, 0]
    for i in range(min(3, 9)):  # Plot first 3 trajectories
        _M_central = M_central[i]

        # Generate initial conditions using orbital parameters
        from datasets.kepler import generate_kepler_states_batch

        _y0 = generate_kepler_states_batch(
            _M_central.item(),
            dataset.a_range,
            dataset.e_range,
            1,
            device=torch.device(device),
        )

        _c = coefficients[i].unsqueeze(0)
        s = 0.01  # Time step for simulation
        n = int(2.0 / s)  # Simulate for 2 time units
        _dt = torch.tensor([s], device=device)

        # Integrate the true trajectory
        x = _y0.clone()
        y_true = [x]
        for k in range(n):
            x = rk4_step(kepler, x, _dt, M_central=_M_central) + x
            y_true.append(x)
        y_true = torch.cat(y_true, dim=0)
        y_true = y_true.detach().cpu().numpy()

        # Integrate the predicted trajectory
        x = _y0.clone()
        x = x.unsqueeze(1)
        _dt = _dt.unsqueeze(0)
        pred = [x]
        for k in range(n):
            x = model((x, _dt), coefficients=_c) + x
            pred.append(x)
        pred = torch.cat(pred, dim=1)
        pred = pred.detach().cpu().numpy()

        # Plot trajectories
        ax3.plot(y_true[:, 0], y_true[:, 1], "b-", alpha=0.6, linewidth=1)
        ax3.plot(pred[0, :, 0], pred[0, :, 1], "r--", alpha=0.8, linewidth=1.5)

        # Mark initial positions
        ax3.plot(y_true[0, 0], y_true[0, 1], "go", markersize=4)

    # Mark central body
    ax3.plot(0, 0, "ko", markersize=6, label="Central Body")
    ax3.set_xlim(-4, 4)
    ax3.set_ylim(-4, 4)
    ax3.set_aspect("equal")
    ax3.set_xlabel("X Position")
    ax3.set_ylabel("Y Position")
    ax3.set_title("Sample Kepler Orbits\n(Solid=True, Dashed=Predicted)")
    ax3.grid(True, alpha=0.3)
    ax3.legend()

    # Plot 4: Final explained variance ratios
    ax4 = axes[1, 1]
    final_scores = scores[-1]  # Last scores (with all basis functions)
    ax4.bar(range(len(final_scores)), final_scores.cpu().numpy())
    ax4.set_xlabel("Basis Function")
    ax4.set_ylabel("Explained Variance Ratio")
    ax4.set_title(
        f"Final Explained Variance (Total Basis: {len(model.basis_functions.basis_functions)})"
    )
    ax4.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

    # Save the model
    torch.save(model.state_dict(), "kepler_pca_model.pth")

print(
    f"Training completed with {len(model.basis_functions.basis_functions)} basis functions"
)
print(
    f"Final explained variance ratios: {scores[-1][:5].cpu().numpy()}"
)  # Show first 5
